Author: BlueLife , Velociraptor
www.sordum.org

########### -- PowerRun v1.4 -- ###########
(Tuesday, February 25, 2020)

Changelog:

1. [Fixed] - Failure to take ownership of TrustedInstaller (Rare)
2. [Added] - Create a shortcut from listed Items
3. [Added] - Code Improvements

########### -- PowerRun v1.3 -- ###########
(Tuesday, 13. February 2018)

Changelog:

1. [Fixed] - PowerRun creates an infinite run in Non english systems (rarely) - Critical
2. [Added] - To seperate Trustedinstaller user "/SYS" parameter suport for command prompt
3. [Added] - To seperate Trustedinstaller user "TrustedInstaller=1/0" parameter suport for GUI
TrustedInstaller=0 ; mean PowerRun runs Only in SYSTEM privileges to change it Please edit PowerRun.ini file.

########### -- PowerRun v1.2 -- ###########
(Tuesday, 06. February 2018)

Changelog:

1. [Fixed] - Parameter with double quotes doesn't work (PowerRun delete it)
2. [Fixed] - Sometimes command Prompt button opens two cmd
3. [Fixed] - Processor usage (reduced)
4. [Fixed] - Some minor GUI bugs
5. [Added] - Normal icon option
6. [Added] � Listed items positions can be changed via drag and drop (on top of each other)


########### -- PowerRun v1.1 -- ###########
( September 08, 2016)

Changelog:

1. [Fixed] - PowerRun Can't delete some registry files which belong to TrustedInstaller
2. [Added] - GUI
3. [Added] - Drag and drop support
4. [Added] - Run with Parameter , Startup Windows state features
5. [Added] - Jump the registry key feature 
6. [Added] - Create a vbs or Bat file feature 
7. [Added] - Cmd support Updated
8. [Added] - Language support

-------------------------------------------------------

########### -- PowerRun v1.0 -- ###########
( August 08, 2016)

PowerRun is a one click portabel freeware tool to launch regedit.exe or Cmd.exe 
with the same privileges as the TrustedInstaller it has No GUI