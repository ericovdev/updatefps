ไThis is to Activate Windows 10 without installing any programs.
How to use
1.Right click Run as Administrator
2. Wait until the black window disappears.